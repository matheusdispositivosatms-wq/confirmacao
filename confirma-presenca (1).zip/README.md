# Confirmação de Presença

Site simples para cadastro de convidados, aprovação por administrador e geração de QR Code único para validação posterior.

## Recursos
- Cadastro com **unicidade** de nome, telefone e email (não permite duplicados).
- Login com **telefone ou email + senha**.
- **Aprovação por admin** é necessária para concluir o cadastro.
- Se a aprovação **demorar mais de 5 minutos**, o frontend exibe: _"Nenhum atendente disponível, tente novamente mais tarde"_.
- Geração de **QR Code único (token)** para cada convidado aprovado.
- **Painel do administrador** protegido por sessão: lista convidados, aprova e marca check-in por token.

## Requisitos
- Opção A: Node.js LTS (18+ ou 20+)
- Opção B: Docker e Docker Compose

## Como rodar (sem Docker)
1. Instale o Node.js (https://nodejs.org/)
2. Extraia este projeto em uma pasta.
3. (Opcional) Copie `.env.example` para `.env` e altere valores se desejar.
4. No terminal, dentro da pasta do projeto:
   ```bash
   npm install
   npm start
   ```
5. Abra `http://localhost:3000` no navegador.

### Fluxo
- **Admin**: acesse `http://localhost:3000/admin`, faça login (padrão: `admin` / `1234`) e aprove solicitações.
- **Usuário**:
  - Acesse a aba **Cadastrar-se**, preencha os dados e confirme.
  - A página começará a **esperar aprovação**. Se passar de 5 minutos sem aprovação, exibirá a mensagem de indisponibilidade.
  - Após aprovado, vá à aba **Fazer Login**, entre com telefone/email + senha e receba seu **QR Code** e **token**.
- **Check-in**: no painel admin, use “Check-in por Token” e cole o token (copiado do QR) para marcar presença.

## Como rodar (com Docker)
1. Instale Docker e Docker Compose.
2. No terminal, dentro da pasta do projeto:
   ```bash
   docker compose up --build
   ```
3. Acesse `http://localhost:3000`.
4. Para derrubar:
   ```bash
   docker compose down
   ```

## Personalizações
- Mude o admin padrão criando um arquivo `.env` com:
  ```env
  ADMIN_USER=seu-usuario
  ADMIN_PASS=sua-senha
  SESSION_SECRET=um-segredo-longo
  PORT=3000
  ```
- Para **resetar o banco**, pare o app e apague `db.sqlite` (atenção: você perderá todos os cadastros).

## Observações importantes
- Este projeto é um **exemplo educativo**. Para uso real, considere:
  - HTTPS, validação de dados mais rígida e políticas de senha.
  - Confirmação de email/telefone.
  - Logs e auditoria.
  - Rate limiting, CORS e cabeçalhos de segurança.
  - Uso de banco de dados gerenciado.
