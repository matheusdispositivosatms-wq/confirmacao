let POLL_INTERVAL_MS = 5000; // 5s
let POLL_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutos

function show(which) {
  const cad = document.getElementById('cadastro');
  const log = document.getElementById('login');
  const tabCad = document.getElementById('tab-cadastro');
  const tabLog = document.getElementById('tab-login');

  if (which === 'cadastro') {
    cad.classList.remove('hidden');
    log.classList.add('hidden');
    tabCad.classList.add('active');
    tabLog.classList.remove('active');
  } else {
    cad.classList.add('hidden');
    log.classList.remove('hidden');
    tabCad.classList.remove('active');
    tabLog.classList.add('active');
  }
}

async function cadastrar() {
  const nome = document.getElementById('nome').value.trim();
  const telefone = document.getElementById('telefone').value.trim();
  const email = document.getElementById('email').value.trim();
  const senha = document.getElementById('senha').value;

  const msg = document.getElementById('msgCadastro');
  const waiting = document.getElementById('aguardando');
  const timeoutEl = document.getElementById('timeout');
  msg.textContent = '';
  waiting.style.display = 'none';
  timeoutEl.style.display = 'none';

  const res = await fetch('/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome, telefone, email, senha })
  });
  const data = await res.json();
  if (data.error) {
    msg.textContent = data.error;
    return;
  }

  msg.textContent = data.message || 'Cadastro enviado.';
  waiting.style.display = 'block';

  // Inicia polling de aprovação, com timeout de 5 minutos
  const start = Date.now();
  const userId = data.userId;
  let approved = false;

  while (Date.now() - start < POLL_TIMEOUT_MS) {
    try {
      const sres = await fetch(`/status/${userId}`);
      const sdata = await sres.json();
      if (sdata && sdata.aprovado) {
        approved = true;
        break;
      }
    } catch (e) {}
    await new Promise(r => setTimeout(r, POLL_INTERVAL_MS));
  }

  if (!approved) {
    timeoutEl.style.display = 'block';
    waiting.style.display = 'none';
  } else {
    waiting.textContent = 'Aprovado! Agora você pode fazer login.';
  }
}

async function logar() {
  const login = document.getElementById('loginUser').value.trim();
  const senha = document.getElementById('loginSenha').value;
  const msg = document.getElementById('msgLogin');
  const qrArea = document.getElementById('qrArea');
  const qrImg = document.getElementById('qrImg');
  const qrToken = document.getElementById('qrToken');

  msg.textContent = '';
  qrArea.classList.add('hidden');
  qrImg.src = '';
  qrToken.textContent = '';

  const res = await fetch('/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ login, senha })
  });
  const data = await res.json();
  if (data.error) {
    msg.textContent = data.error;
    return;
  }

  msg.textContent = 'Login realizado!';
  if (data.qrDataUrl) {
    qrImg.src = data.qrDataUrl;
    qrToken.textContent = `Token: ${data.token}`;
    qrArea.classList.remove('hidden');
  }
}
