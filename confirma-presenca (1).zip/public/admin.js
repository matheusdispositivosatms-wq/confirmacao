const $ = (q) => document.querySelector(q);

async function adminLogin() {
  const usuario = $('#admUser').value.trim();
  const senha = $('#admPass').value;

  const res = await fetch('/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usuario, senha })
  });
  const data = await res.json();
  const msg = $('#admMsg');
  if (data.error) {
    msg.textContent = data.error;
    return;
  }
  msg.textContent = 'Logado!';
  $('#adminLogin').classList.add('hidden');
  $('#adminArea').classList.remove('hidden');
  loadUsers();
}

async function adminLogout() {
  await fetch('/admin/logout', { method: 'POST' });
  location.reload();
}

function fmt(v) { return v ?? ''; }

async function loadUsers() {
  const tbody = $('#usersTable tbody');
  tbody.innerHTML = '<tr><td colspan="9">Carregando...</td></tr>';
  const res = await fetch('/admin/users');
  const data = await res.json();
  if (data.error) {
    tbody.innerHTML = `<tr><td colspan="9">${data.error}</td></tr>`;
    return;
  }
  if (!Array.isArray(data) || data.length === 0) {
    tbody.innerHTML = '<tr><td colspan="9">Nenhum registro encontrado.</td></tr>';
    return;
  }
  tbody.innerHTML = '';
  for (const u of data) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${u.id}</td>
      <td>${fmt(u.nome)}</td>
      <td>${fmt(u.telefone)}</td>
      <td>${fmt(u.email)}</td>
      <td>${u.aprovado ? '✅' : '⏳'}</td>
      <td>${u.checkin ? '✅' : '—'}</td>
      <td>${fmt(u.criado_em)}</td>
      <td>${fmt(u.aprovado_em) || '—'}</td>
      <td>
        ${u.aprovado ? '—' : `<button data-id="${u.id}" class="approve">Aprovar</button>`}
      </td>
    `;
    tbody.appendChild(tr);
  }

  tbody.querySelectorAll('button.approve').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-id');
      const res = await fetch('/admin/aprovar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: Number(id) })
      });
      const data = await res.json();
      if (data.error) {
        alert(data.error);
      } else {
        loadUsers();
      }
    });
  });
}

async function checkin() {
  const token = $('#tokenInput').value.trim();
  const msg = $('#checkinMsg');
  msg.textContent = '';
  if (!token) { msg.textContent = 'Informe um token.'; return; }

  const res = await fetch('/admin/checkin', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token })
  });
  const data = await res.json();
  if (data.error) {
    msg.textContent = data.error;
  } else {
    msg.textContent = data.message || 'Check-in confirmado!';
    $('#tokenInput').value = '';
    loadUsers();
  }
}
