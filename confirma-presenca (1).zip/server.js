// Servidor Express + SQLite para confirmação de presença
// Observação: este projeto é educativo. Para produção, configure HTTPS, revise sessões e políticas de segurança.

require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const QRCode = require('qrcode');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const app = express();

const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev-secret';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS_PLAIN = process.env.ADMIN_PASS || '1234';

app.use(express.json());
app.use(session({
  name: 'sessao',
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true }
}));
app.use(express.static(path.join(__dirname, 'public')));

const db = new sqlite3.Database(path.join(__dirname, 'db.sqlite'));
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT UNIQUE,
    telefone TEXT UNIQUE,
    email TEXT UNIQUE,
    senha TEXT NOT NULL,
    aprovado INTEGER DEFAULT 0,
    checkin INTEGER DEFAULT 0,
    qr_token TEXT UNIQUE,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    aprovado_em DATETIME
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario TEXT UNIQUE NOT NULL,
    senha_hash TEXT NOT NULL
  )`);

  // Garante admin padrão (usa variáveis de ambiente se existirem)
  const hash = bcrypt.hashSync(ADMIN_PASS_PLAIN, 10);
  db.run(
    'INSERT OR IGNORE INTO admins (id, usuario, senha_hash) VALUES (1, ?, ?)',
    [ADMIN_USER, hash]
  );
});

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ error: 'Não autorizado' });
}

// ---------------- Rotas Públicas ----------------

// Cadastro de usuário
app.post('/register', (req, res) => {
  let { nome, telefone, email, senha } = req.body || {};
  nome = (nome || '').trim();
  telefone = (telefone || '').trim();
  email = (email || '').trim().toLowerCase();
  senha = (senha || '');

  if (!nome || !telefone || !email || !senha) {
    return res.json({ error: 'Preencha todos os campos.' });
  }

  const senhaHash = bcrypt.hashSync(senha, 10);

  // Verifica duplicidades (nome/telefone/email)
  db.get(
    'SELECT id FROM users WHERE nome = ? OR telefone = ? OR email = ?',
    [nome, telefone, email],
    (err, row) => {
      if (err) return res.json({ error: 'Erro ao verificar usuário.' });
      if (row) return res.json({ error: 'Dados já cadastrados (nome/telefone/email).' });

      db.run(
        'INSERT INTO users (nome, telefone, email, senha) VALUES (?, ?, ?, ?)',
        [nome, telefone, email, senhaHash],
        function (err2) {
          if (err2) {
            if (err2.code === 'SQLITE_CONSTRAINT') {
              return res.json({ error: 'Dados já cadastrados (nome/telefone/email).' });
            }
            return res.json({ error: 'Erro ao cadastrar.' });
          }
          return res.json({ success: true, userId: this.lastID, message: 'Cadastro solicitado. Aguarde aprovação do administrador.' });
        }
      );
    }
  );
});

// Status de aprovação (polling do frontend após cadastro)
app.get('/status/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  db.get('SELECT aprovado FROM users WHERE id = ?', [id], (err, row) => {
    if (err || !row) return res.json({ error: 'Usuário não encontrado.' });
    return res.json({ aprovado: !!row.aprovado });
  });
});

// Login de usuário (telefone OU email) + senha
app.post('/login', (req, res) => {
  const { login, senha } = req.body || {};
  if (!login || !senha) return res.json({ error: 'Informe login e senha.' });

  db.get(
    'SELECT * FROM users WHERE telefone = ? OR email = ?',
    [login, (login || '').toLowerCase()],
    async (err, user) => {
      if (err) return res.json({ error: 'Erro no login.' });
      if (!user) return res.json({ error: 'Usuário não encontrado.' });

      const ok = bcrypt.compareSync(senha, user.senha);
      if (!ok) return res.json({ error: 'Senha incorreta.' });
      if (!user.aprovado) return res.json({ error: 'Aguardando aprovação do administrador.' });

      // Gera token único se ainda não existir
      if (!user.qr_token) {
        const token = crypto.randomUUID();
        db.run('UPDATE users SET qr_token = ? WHERE id = ?', [token, user.id]);
        user.qr_token = token;
      }

      // Conteúdo codificado no QR (apenas o token)
      const payload = `CONFIRM|${user.qr_token}`;
      try {
        const qrDataUrl = await QRCode.toDataURL(payload);
        return res.json({ success: true, qrDataUrl, token: user.qr_token });
      } catch (e) {
        return res.json({ error: 'Falha ao gerar QR Code.' });
      }
    }
  );
});

// Página Admin (HTML estático)
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// ---------------- Rotas de Administração ----------------

// Login de admin (cria sessão)
app.post('/admin/login', (req, res) => {
  const { usuario, senha } = req.body || {};
  if (!usuario || !senha) return res.json({ error: 'Informe usuário e senha.' });

  db.get('SELECT * FROM admins WHERE usuario = ?', [usuario], (err, admin) => {
    if (err) return res.json({ error: 'Erro no login.' });
    if (!admin) return res.json({ error: 'Admin não encontrado.' });
    const ok = bcrypt.compareSync(senha, admin.senha_hash);
    if (!ok) return res.json({ error: 'Senha incorreta.' });

    req.session.isAdmin = true;
    req.session.adminUser = usuario;
    return res.json({ success: true });
  });
});

app.post('/admin/logout', (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
});

// Lista de usuários (somente admin)
app.get('/admin/users', requireAdmin, (req, res) => {
  db.all('SELECT id, nome, telefone, email, aprovado, checkin, criado_em, aprovado_em, qr_token FROM users ORDER BY criado_em DESC', [], (err, rows) => {
    if (err) return res.json({ error: 'Erro ao listar usuários.' });
    return res.json(rows);
  });
});

// Aprovar usuário (gera token se não existir)
app.post('/admin/aprovar', requireAdmin, (req, res) => {
  const { id } = req.body || {};
  if (!id) return res.json({ error: 'ID obrigatório.' });

  const token = crypto.randomUUID();
  db.run('UPDATE users SET aprovado = 1, aprovado_em = CURRENT_TIMESTAMP, qr_token = COALESCE(qr_token, ?) WHERE id = ?', [token, id], function(err) {
    if (err || this.changes === 0) return res.json({ error: 'Falha ao aprovar.' });
    return res.json({ success: true });
  });
});

// Check-in (valida token do QR, somente admin)
app.post('/admin/checkin', requireAdmin, (req, res) => {
  const { token } = req.body || {};
  if (!token) return res.json({ error: 'Token obrigatório.' });

  db.get('SELECT id, nome, aprovado, checkin FROM users WHERE qr_token = ?', [token], (err, user) => {
    if (err) return res.json({ error: 'Erro ao verificar token.' });
    if (!user) return res.json({ error: 'Token inválido.' });
    if (!user.aprovado) return res.json({ error: 'Usuário ainda não aprovado.' });
    if (user.checkin) return res.json({ error: 'Presença já confirmada.' });

    db.run('UPDATE users SET checkin = 1 WHERE id = ?', [user.id], function (err2) {
      if (err2) return res.json({ error: 'Erro ao marcar presença.' });
      return res.json({ success: true, message: `Presença confirmada para ${user.nome}.` });
    });
  });
});

// Fallback para SPA simples (apenas /)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
